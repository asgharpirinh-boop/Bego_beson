const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => [...r.querySelectorAll(s)];
const STORE_KEY = "bego-beson-demo-requests-v1";
let requests = JSON.parse(localStorage.getItem(STORE_KEY) || "[]");
let currentRequestId = null;
let activeFilter = "همه";
const samples = [
 {id:"sample1",title:"دنبال دستگاه اسپرسوساز باکیفیت هستم",category:"کالاها",city:"تهران",budget:"حدود ۸ میلیون تومان",kind:"پیدا کن",description:"دستگاه سالم و ترجیحاً نو، همراه با ضمانت معتبر.",offers:12,icon:"☕"},
 {id:"sample2",title:"ساخت میز چوبی طبق عکس",category:"ساخت سفارشی",city:"بوشهر",budget:"توافقی",kind:"بساز",description:"یک میز ساده با ابعاد سفارشی می‌خواهم. سازنده نمونه‌کار بفرستد.",offers:4,icon:"🪑"},
 {id:"sample3",title:"تعمیرکار کولر گازی نیاز دارم",category:"خدمات",city:"شیراز",budget:"پس از بازدید",kind:"جور کن",description:"برای سرویس و بررسی کولر گازی به متخصص نیاز دارم.",offers:3,icon:"🧰"}
];
function allItems(){return [...requests,...samples]}
function faNum(n){return Number(n).toLocaleString("fa-IR")}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400)}
function showPage(name){
 $$(".page").forEach(p=>p.classList.remove("active"));
 const page=$("#"+name+"Page"); if(page) page.classList.add("active");
 $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.go===name));
 if(name==="home") renderRecent();
 if(name==="search") renderAll();
 if(name==="profile") $("#myRequestCount").textContent=faNum(requests.length);
 window.scrollTo({top:0,behavior:"smooth"});
}
function card(item){
 return `<button class="request-card" data-detail="${item.id}">
  <span class="request-thumb">${item.icon||"📦"}</span>
  <span class="request-info"><b>${escapeHtml(item.title)}</b><small>${escapeHtml(item.city||"سراسر ایران")} • ${escapeHtml(item.category||"سایر")} • ${faNum(item.offers||0)} پیشنهاد</small><span class="request-price">${escapeHtml(item.budget||"بودجه توافقی")}</span></span>
  <span class="card-arrow">‹</span></button>`;
}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderRecent(){$("#recentRequests").innerHTML=allItems().slice(0,4).map(card).join("")}
function renderAll(){
 const q=($("#feedSearch")?.value||"").trim().toLowerCase();
 const list=allItems().filter(x=>(activeFilter==="همه"||x.category===activeFilter)&&(`${x.title} ${x.city} ${x.category}`).toLowerCase().includes(q));
 $("#allRequests").innerHTML=list.length?list.map(card).join(""):'<div class="empty-state"><div>🔎</div><h3>درخواستی پیدا نشد</h3><p>عبارت دیگری جست‌وجو کن یا فیلتر را تغییر بده.</p></div>';
}
function openDetail(id){
 const item=allItems().find(x=>x.id===id); if(!item)return;
 currentRequestId=id;
 $("#detailContent").innerHTML=`<article class="detail-box"><div class="request-thumb">${item.icon||"📦"}</div><h2>${escapeHtml(item.title)}</h2><div class="detail-meta"><span class="pill">${escapeHtml(item.category)}</span><span class="pill">${escapeHtml(item.city||"سراسر ایران")}</span><span class="pill">${escapeHtml(item.kind||"درخواست")}</span></div><p>${escapeHtml(item.description||"توضیحات بیشتری ثبت نشده است.")}</p><b class="request-price">بودجه: ${escapeHtml(item.budget||"توافقی")}</b><p>تعداد پیشنهادها: ${faNum(item.offers||0)}</p><div class="offer-form"><h3>ارسال پیشنهاد (نمایشی)</h3><label class="field-label">قیمت پیشنهادی (تومان)</label><input id="offerPrice" class="input" inputmode="numeric" placeholder="مبلغ پیشنهادی"><label class="field-label">توضیح پیشنهاد</label><textarea id="offerText" class="input" rows="3" placeholder="کالا یا خدمتت را توضیح بده..."></textarea><button class="primary-btn full" id="sendOffer">ارسال پیشنهاد</button></div></article>`;
 showPage("detail");
 $("#sendOffer").onclick=()=>{if(!$("#offerPrice").value.trim()){toast("لطفاً قیمت پیشنهادی را وارد کن.");return}toast("پیشنهاد به‌صورت آزمایشی ثبت شد؛ برای ثبت واقعی باید سرور وصل شود.")};
}
$("#requestForm").addEventListener("submit",e=>{
 e.preventDefault();
 const title=$("#requestTitle").value.trim(); if(!title){toast("عنوان درخواست را وارد کن.");return}
 const item={id:"r"+Date.now(),title,description:$("#requestDescription").value.trim(),kind:$('input[name="kind"]:checked').value,category:$("#category").value,condition:$("#condition").value,budget:$("#budget").value.trim()?$("#budget").value.trim()+" تومان":"توافقی",city:$("#city").value.trim()||"نامشخص",deadline:$("#deadline").value,offers:0,icon:"📦",createdAt:Date.now()};
 requests.unshift(item);localStorage.setItem(STORE_KEY,JSON.stringify(requests));
 $("#requestForm").reset();$("#mediaPreview").innerHTML="";toast("درخواست روی این دستگاه ذخیره شد.");showPage("home");
});
$("#mediaInput").addEventListener("change",e=>{
 const box=$("#mediaPreview");box.innerHTML="";
 [...e.target.files].slice(0,5).forEach(f=>{if(f.type.startsWith("image/")){const img=document.createElement("img");img.src=URL.createObjectURL(f);box.append(img)}else{const tag=document.createElement("span");tag.textContent="🎬 "+f.name;box.append(tag)}});
 if(e.target.files.length>5)toast("حداکثر ۵ فایل در پیش‌نمایش نمایش داده می‌شود.");
});
document.addEventListener("click",e=>{
 const go=e.target.closest("[data-go]");if(go){showPage(go.dataset.go);return}
 const c=e.target.closest("[data-detail]");if(c){openDetail(c.dataset.detail);return}
 const cat=e.target.closest("[data-category]");if(cat){activeFilter=cat.dataset.category;$$(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter===activeFilter));showPage("search");renderAll()}
 const f=e.target.closest("[data-filter]");if(f){activeFilter=f.dataset.filter;$$(".filter").forEach(b=>b.classList.toggle("active",b===f));renderAll()}
});
$("#feedSearch").addEventListener("input",renderAll);
$("#homeSearch").addEventListener("keydown",e=>{if(e.key==="Enter"){$("#feedSearch").value=e.target.value;showPage("search");renderAll()}});
$$(".type-option").forEach(el=>el.addEventListener("click",()=>{$$(".type-option").forEach(x=>x.classList.remove("selected"));el.classList.add("selected")}));
$("#notifyBtn").onclick=()=>toast("اعلان تازه‌ای نداری.");
$("#menuBtn").onclick=()=>toast("برای دسترسی از نوار پایین استفاده کن.");
if("serviceWorker" in navigator && location.protocol.startsWith("http")){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}))}
renderRecent();renderAll();